let Component = props => {
  // Enter code here so that the component outputs what is expected!
};

ReactDOM.render(
  // Enter code here so the component is rendered to the #target div!
);